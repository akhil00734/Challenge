﻿using Challenge1.Models;
using Challenge1.Services;
using Microsoft.AspNetCore.Mvc;

namespace Challenge1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientGroups : ControllerBase
    {
        private readonly IPatientService patientService;
        public PatientGroups(IPatientService service)
        {
            this.patientService = service;
        }
        [HttpPost]
        [Route("Calculate")]
        public Groups Calculate(MatrixModel matrixModel)
        {
            return patientService.Calculate(matrixModel);
        }
    }
}
