﻿using Challenge1.Models;

namespace Challenge1.Services
{
    public interface IPatientService
    {
        Groups Calculate(MatrixModel matModel);
    }
}
